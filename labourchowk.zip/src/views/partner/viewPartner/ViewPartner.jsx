import React from 'react'

const ViewPartner = () => {
  return (
    <div>View Partner Detail</div>
  )
}

export default ViewPartner